#include <cassert>
int main() { assert(false); }
